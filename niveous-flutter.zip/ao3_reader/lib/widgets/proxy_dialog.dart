import 'package:flutter/material.dart';

import '../ao3_client.dart';
import '../app_state.dart';
import '../palettes.dart';

/// 网络与代理设置弹窗
class ProxyDialog extends StatefulWidget {
  const ProxyDialog({super.key});

  static Future<void> show(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (_) => const ProxyDialog(),
    );
  }

  @override
  State<ProxyDialog> createState() => _ProxyDialogState();
}

class _ProxyDialogState extends State<ProxyDialog> {
  late final TextEditingController _proxyCtrl;
  late final TextEditingController _urlCtrl;
  bool _useProxy = false;
  bool _testing = false;
  String? _testResult;

  @override
  void initState() {
    super.initState();
    final AppState s = AppScope.of(context);
    _proxyCtrl = TextEditingController(text: s.proxyHost ?? '127.0.0.1:7890');
    _urlCtrl = TextEditingController(text: s.ao3BaseUrl);
    _useProxy = s.proxyHost != null && s.proxyHost!.isNotEmpty;
  }

  @override
  void dispose() {
    _proxyCtrl.dispose();
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _testConnection(AppState s) async {
    setState(() {
      _testing = true;
      _testResult = null;
    });

    final String? p = _useProxy ? _proxyCtrl.text.trim() : null;
    final testClient =
        Ao3Client(baseUrl: _urlCtrl.text.trim(), proxy: p, cookies: s.ao3Cookies);
    final stopwatch = Stopwatch()..start();
    final res = await testClient.searchWorks(query: 'test', page: 1);
    stopwatch.stop();

    setState(() {
      _testing = false;
      if (res.success) {
        _testResult = '✅ 连接成功！延迟 ${stopwatch.elapsedMilliseconds} ms';
      } else {
        _testResult = '❌ 连接失败: ${res.error}\n(建议开启手机梯子/代理，或使用【网页嗅探一键导入】)';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    return AlertDialog(
      backgroundColor: p.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(
        children: <Widget>[
          Icon(Icons.wifi_outlined, color: s.accent, size: 22),
          const SizedBox(width: 8),
          Text(
            '网络与域名设置',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w600,
              fontFamily: 'serif',
              color: p.ink,
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '⚠️ 重要说明：\n'
              '1. 国内直连 AO3 通常需要开启手机代理/VPN（如 Clash / v2ray / Surge 等）。\n'
              '2. 绝大部分镜像站本质也是反向代理，同样在 Cloudflare 防护之后，因此也需要人机验证。若遇 525 或 403，推荐直接使用顶部的【网页一键导入】。',
              style: TextStyle(fontSize: 11.5, height: 1.5, color: p.muted),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  '指定本地应用代理',
                  style: TextStyle(fontSize: 13.5, color: p.ink),
                ),
                Switch(
                  value: _useProxy,
                  activeColor: s.accent,
                  onChanged: (bool v) {
                    setState(() => _useProxy = v);
                  },
                ),
              ],
            ),
            if (_useProxy) ...<Widget>[
              const SizedBox(height: 6),
              TextField(
                controller: _proxyCtrl,
                style: TextStyle(fontSize: 13, color: p.ink),
                decoration: InputDecoration(
                  labelText: '代理地址 (例 127.0.0.1:7890)',
                  labelStyle: TextStyle(fontSize: 12, color: p.muted),
                  filled: true,
                  fillColor: p.paper,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: p.line),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 14),
            Text(
              'AO3 域名 / 镜像源',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: p.ink),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _urlCtrl,
              style: TextStyle(fontSize: 13, color: p.ink),
              decoration: InputDecoration(
                filled: true,
                fillColor: p.paper,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: p.line),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: <Widget>[
                ActionChip(
                  label: const Text('官方主站', style: TextStyle(fontSize: 11)),
                  onPressed: () =>
                      _urlCtrl.text = 'https://archiveofourown.org',
                ),
                ActionChip(
                  label: const Text('镜像 1 (nightskies)', style: TextStyle(fontSize: 11)),
                  onPressed: () => _urlCtrl.text = 'https://nightskies.top',
                ),
                ActionChip(
                  label: const Text('镜像 2 (ao3.org)', style: TextStyle(fontSize: 11)),
                  onPressed: () => _urlCtrl.text = 'https://ao3.org',
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (_testResult != null)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: p.paper,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _testResult!,
                  style: TextStyle(fontSize: 12, height: 1.5, color: p.ink),
                ),
              ),
            SizedBox(
              width: double.infinity,
              height: 38,
              child: OutlinedButton(
                onPressed: _testing ? null : () => _testConnection(s),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: p.line),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: _testing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(
                        '测试连接 AO3',
                        style: TextStyle(fontSize: 13, color: s.accent),
                      ),
              ),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('取消', style: TextStyle(color: p.muted)),
        ),
        ElevatedButton(
          onPressed: () {
            s.setProxy(_useProxy ? _proxyCtrl.text.trim() : null);
            s.setBaseUrl(_urlCtrl.text.trim());
            Navigator.of(context).pop();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('网络设置已保存'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: s.accent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
          ),
          child: const Text('保存'),
        ),
      ],
    );
  }
}
