import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../palettes.dart';

/// 1:1 还原 Claude 脚本设计的精美搜索卡片
class WorkCard extends StatefulWidget {
  const WorkCard({
    super.key,
    required this.work,
    required this.bookmarked,
    required this.onBookmark,
    required this.onOpen,
  });

  final Work work;
  final bool bookmarked;
  final VoidCallback onBookmark;
  final VoidCallback onOpen;

  @override
  State<WorkCard> createState() => _WorkCardState();
}

class _WorkCardState extends State<WorkCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    final Work work = widget.work;

    final double baseFs = s.cardFontSize;
    final bool isDark = p.dark;

    final Color cardBg = isDark ? p.card : Colors.white;
    final Color tagBg = isDark ? const Color(0xFF2E273A) : const Color(0xFFF3EEF9);
    final Color tagText = isDark ? const Color(0xFFC7B8E3) : const Color(0xFF5E4E7A);

    final Color metaBg = isDark ? const Color(0xFF272530) : const Color(0xFFF5F4F7);
    final Color metaText = isDark ? const Color(0xFFAFA7BA) : const Color(0xFF6E677B);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: p.line.withOpacity(0.8)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.35 : 0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: widget.onOpen, // 点卡片直接进阅读器！
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // 1. 文章标题 (.ao3-card-title)
                Text(
                  work.displayTitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: baseFs + 2.5,
                    height: 1.35,
                    fontWeight: FontWeight.w700,
                    color: p.ink,
                    fontFamily: s.globalFontFamily,
                  ),
                ),
                if (work.hasZhTitle) ...<Widget>[
                  const SizedBox(height: 2),
                  Text(
                    work.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: baseFs - 2,
                      fontStyle: FontStyle.italic,
                      color: p.muted,
                    ),
                  ),
                ],
                const SizedBox(height: 4),

                // 2. 作者 (.ao3-card-author)
                Text(
                  'by ${work.author}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: baseFs - 1.5,
                    color: p.muted,
                  ),
                ),
                const SizedBox(height: 8),

                // 3. 元数据胶囊行 (.ao3-card-meta: 📝 字数、📖 章节、分级、完结)
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: <Widget>[
                    _MetaPill(
                      text: '📝 ${work.words} 字',
                      bg: metaBg,
                      textColor: metaText,
                    ),
                    _MetaPill(
                      text: '📖 ${work.chapterCount > 0 ? "${work.chapterCount} 章" : "全 1 章"}',
                      bg: metaBg,
                      textColor: metaText,
                    ),
                    _MetaPill(
                      text: '分级: ${work.rating}',
                      bg: metaBg,
                      textColor: metaText,
                    ),
                    if (work.complete)
                      _MetaPill(
                        text: '完结',
                        bg: isDark ? const Color(0xFF1B3322) : const Color(0xFFE8F5E9),
                        textColor: isDark ? const Color(0xFF81C784) : const Color(0xFF2E7D32),
                      ),
                  ],
                ),
                const SizedBox(height: 8),

                // 4. 标签小胶囊行 (.ao3-card-tags: 淡紫底色 + 雅致文字，绝无刺眼大红)
                Wrap(
                  spacing: 6,
                  runSpacing: 5,
                  children: <Widget>[
                    if (work.fandom.isNotEmpty)
                      _TagPill(text: work.fandom, bg: tagBg, textColor: tagText),
                    if (work.relationship.isNotEmpty)
                      _TagPill(text: '❤️ ${work.relationship}', bg: tagBg, textColor: tagText),
                    ...work.tags.take(3).map(
                          (String t) => _TagPill(text: t, bg: tagBg, textColor: tagText),
                        ),
                  ],
                ),
                const SizedBox(height: 8),

                // 5. 简介摘要 (.ao3-card-summary: 默认两行，点击展开/折叠)
                if (work.summary.isNotEmpty) ...<Widget>[
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setState(() => _expanded = !_expanded),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          work.summaryZh.isNotEmpty ? work.summaryZh : work.summary,
                          maxLines: _expanded ? null : 2,
                          overflow: _expanded ? TextOverflow.visible : TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: baseFs - 1.5,
                            height: 1.6,
                            color: p.ink2,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _expanded ? '收起 ▴' : '展开简介 ▾',
                          style: TextStyle(
                            fontSize: 11,
                            color: s.accent,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                ],

                // 6. 底部信息行 (.ao3-card-footer: ❤️ Kudos、💬 阅读量、🕐 纯数字日期)
                Container(
                  padding: const EdgeInsets.only(top: 8),
                  decoration: BoxDecoration(
                    border: Border(top: BorderSide(color: p.line.withOpacity(0.6))),
                  ),
                  child: Row(
                    children: <Widget>[
                      Text('❤️ ${work.kudos}',
                          style: TextStyle(fontSize: 11.5, color: p.muted)),
                      const SizedBox(width: 12),
                      Text('💬 ${work.hits}',
                          style: TextStyle(fontSize: 11.5, color: p.muted)),
                      const SizedBox(width: 12),
                      // 纯阿拉伯数字日期，例如 2024.03.15 或 2024-03-15
                      Text('🕐 ${work.displayArabicDate.replaceAll('.', '-')}',
                          style: TextStyle(fontSize: 11.5, color: p.muted)),
                      const Spacer(),
                      IconButton(
                        icon: Icon(
                          widget.bookmarked ? Icons.bookmark : Icons.bookmark_border,
                          color: widget.bookmarked ? s.accent : p.muted,
                          size: 20,
                        ),
                        onPressed: widget.onBookmark,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        tooltip: widget.bookmarked ? '移出书库' : '加入书库',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MetaPill extends StatelessWidget {
  const _MetaPill({
    required this.text,
    required this.bg,
    required this.textColor,
  });

  final String text;
  final Color bg;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2.5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: textColor,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

class _TagPill extends StatelessWidget {
  const _TagPill({
    required this.text,
    required this.bg,
    required this.textColor,
  });

  final String text;
  final Color bg;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2.5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: textColor,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
