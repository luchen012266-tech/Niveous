import 'dart:async';
import 'dart:io';

import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart' as http_io;

import 'models.dart';

/// AO3 登录与抓取结果
class Ao3Result<T> {
  final bool success;
  final T? data;
  final String? error;

  const Ao3Result.ok(this.data)
      : success = true,
        error = null;

  const Ao3Result.err(this.error)
      : success = false,
        data = null;
}

/// AO3 客户端（处理网络、代理、Cookie、CSRF、HTML 解析）
class Ao3Client {
  Ao3Client({
    this.baseUrl = 'https://archiveofourown.org',
    this.proxy,
    this.cookies = '',
  });

  final String baseUrl;
  String get cleanBaseUrl =>
      baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
  final String? proxy;
  String cookies;

  static const String defaultUserAgent =
      'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36';

  http.Client _createClient() {
    final HttpClient inner = HttpClient();
    inner.userAgent = defaultUserAgent;
    inner.connectionTimeout = const Duration(seconds: 15);

    if (proxy != null && proxy!.trim().isNotEmpty) {
      final String p =
          proxy!.trim().replaceAll('http://', '').replaceAll('https://', '');
      inner.findProxy = (Uri uri) => 'PROXY $p; DIRECT';
    } else {
      inner.findProxy = (Uri uri) => HttpClient.findProxyFromEnvironment(uri);
    }
    inner.badCertificateCallback =
        (X509Certificate cert, String host, int port) => true;
    return http_io.IOClient(inner);
  }

  Map<String, String> _buildHeaders({String? referer, String? contentType}) {
    final Map<String, String> headers = <String, String>{
      'User-Agent': defaultUserAgent,
      'Accept':
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
      'Sec-Ch-Ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
      'Sec-Ch-Ua-Mobile': '?1',
      'Sec-Ch-Ua-Platform': '"Android"',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1',
    };
    if (cookies.isNotEmpty) {
      headers['Cookie'] = cookies;
    }
    if (referer != null) {
      headers['Referer'] = referer;
    }
    if (contentType != null) {
      headers['Content-Type'] = contentType;
    }
    return headers;
  }

  void _mergeCookies(http.Response resp) {
    final String? setCookie = resp.headers['set-cookie'];
    if (setCookie == null || setCookie.isEmpty) return;

    final Map<String, String> map = <String, String>{};
    if (cookies.isNotEmpty) {
      for (final String part in cookies.split(';')) {
        final int idx = part.indexOf('=');
        if (idx > 0) {
          map[part.substring(0, idx).trim()] = part.substring(idx + 1).trim();
        }
      }
    }

    for (final String item in setCookie.split(RegExp(r',(?=\s*[A-Za-z0-9_\-]+=[^;]+)'))) {
      final String mainPart = item.split(';')[0];
      final int idx = mainPart.indexOf('=');
      if (idx > 0) {
        final String k = mainPart.substring(0, idx).trim();
        final String v = mainPart.substring(idx + 1).trim();
        if (v.isNotEmpty && v != '""') {
          map[k] = v;
        }
      }
    }

    cookies = map.entries.map((MapEntry<String, String> e) => '${e.key}=${e.value}').join('; ');
  }

  // =========================================================================
  // 1. 登录 AO3
  // =========================================================================
  Future<Ao3Result<String>> login(String username, String password) async {
    final http.Client client = _createClient();
    try {
      final Uri loginUri = Uri.parse('$cleanBaseUrl/users/login');
      final http.Response getResp = await client
          .get(loginUri, headers: _buildHeaders())
          .timeout(const Duration(seconds: 20));

      _mergeCookies(getResp);

      if (getResp.statusCode == 403) {
        return const Ao3Result.err('AO3 开启了 Cloudflare 人机验证盾 (HTTP 403)，请点击【官方网页安全登录】通过验证');
      }

      if (getResp.statusCode >= 500) {
        return Ao3Result.err('AO3 服务器暂不可用 (HTTP ${getResp.statusCode})，请稍后再试');
      }

      final dom.Document doc = html_parser.parse(getResp.body);
      final dom.Element? tokenInput = doc.querySelector('input[name="authenticity_token"]') ??
          doc.querySelector('meta[name="csrf-token"]');
      final String? token = tokenInput?.attributes['value'] ?? tokenInput?.attributes['content'];

      if (token == null || token.isEmpty) {
        return const Ao3Result.err('无法获取登录校验 Token，可能是 Cloudflare 防护盾拦截，请使用【官方网页安全登录】');
      }

      final Map<String, String> postData = <String, String>{
        'authenticity_token': token,
        'user[login]': username,
        'user[password]': password,
        'user[remember_me]': '1',
        'commit': 'Log In',
      };

      final http.Request request = http.Request('POST', loginUri);
      request.followRedirects = false;
      request.headers.addAll(_buildHeaders(
        referer: loginUri.toString(),
        contentType: 'application/x-www-form-urlencoded',
      ));
      request.bodyFields = postData;

      final http.StreamedResponse streamed =
          await client.send(request).timeout(const Duration(seconds: 25));
      final http.Response postResp = await http.Response.fromStream(streamed);

      _mergeCookies(postResp);

      if (postResp.statusCode == 302 || postResp.statusCode == 303) {
        return Ao3Result.ok(cookies);
      }

      final String body = postResp.body;
      if (body.contains('Log Out') || body.contains('users/logout') || body.contains(username)) {
        return Ao3Result.ok(cookies);
      }

      if (body.contains("doesn't match") || body.contains('The password or user name you entered')) {
        return const Ao3Result.err('用户名或密码错误，请重新核对');
      }

      if (body.contains('Retry later')) {
        return const Ao3Result.err('AO3 限制了请求频率，请等待 1 分钟后再试');
      }

      if (cookies.contains('_otwarchive_session')) {
        return Ao3Result.ok(cookies);
      }

      return const Ao3Result.err('登录未成功，建议点击【官方网页安全登录】');
    } on SocketException catch (_) {
      return const Ao3Result.err('网络无法连接。访问 AO3 通常需要开启手机代理/梯子');
    } on TimeoutException catch (_) {
      return const Ao3Result.err('连接超时。请检查网络代理是否已开启');
    } catch (e) {
      return Ao3Result.err('登录出错: $e');
    } finally {
      client.close();
    }
  }

  // =========================================================================
  // 2. 搜索 / 获取作品列表
  // =========================================================================
  Future<Ao3Result<List<Work>>> searchWorks({
    String query = '',
    String sort = 'kudos',
    String status = 'all',
    int page = 1,
  }) async {
    final http.Client client = _createClient();
    try {
      final Map<String, String> queryParams = <String, String>{
        'page': page.toString(),
        'work_search[sort_direction]': 'desc',
        'commit': 'Search',
      };

      if (query.isNotEmpty) {
        queryParams['work_search[query]'] = query;
      }

      if (sort == 'kudos') {
        queryParams['work_search[sort_column]'] = 'kudos_count';
      } else if (sort == 'hits') {
        queryParams['work_search[sort_column]'] = 'hits';
      } else if (sort == 'words') {
        queryParams['work_search[sort_column]'] = 'word_count';
      } else if (sort == 'revised_at') {
        queryParams['work_search[sort_column]'] = 'revised_at';
      }

      if (status == 'complete') {
        queryParams['work_search[complete]'] = 'T';
      } else if (status == 'wip') {
        queryParams['work_search[complete]'] = 'F';
      }

      final Uri searchUri =
          Uri.parse('$cleanBaseUrl/works/search').replace(queryParameters: queryParams);
      final http.Response resp =
          await client.get(searchUri, headers: _buildHeaders()).timeout(const Duration(seconds: 25));

      _mergeCookies(resp);

      if (resp.statusCode == 403) {
        return const Ao3Result.err('AO3 开启了 Cloudflare 盾 (HTTP 403)。后台请求被拦截，请点击【网页抓取】在网页中一键导入');
      }

      if (resp.statusCode == 525) {
        return const Ao3Result.err('镜像站/源站 SSL 握手失败 (HTTP 525)。说明该镜像源 SSL 失效或被阻断，建议换回主站或点击【网页抓取】');
      }

      if (resp.statusCode == 520 || resp.statusCode == 522 || resp.statusCode == 503) {
        return Ao3Result.err('Cloudflare 服务器响应异常 (HTTP ${resp.statusCode})。建议点击【网页抓取】');
      }

      if (resp.statusCode != 200) {
        return Ao3Result.err('获取作品列表失败 (HTTP ${resp.statusCode})');
      }

      final List<Work> works = parseWorksList(resp.body);
      return Ao3Result.ok(works);
    } on SocketException catch (_) {
      return const Ao3Result.err('网络无法连接。访问 AO3 需要开启代理/梯子');
    } on TimeoutException catch (_) {
      return const Ao3Result.err('获取作品超时，请检查网络代理');
    } catch (e) {
      return Ao3Result.err('解析作品失败: $e');
    } finally {
      client.close();
    }
  }

  // =========================================================================
  // 3. 获取用户书签
  // =========================================================================
  Future<Ao3Result<List<Work>>> fetchBookmarks(String username, {int page = 1}) async {
    final http.Client client = _createClient();
    try {
      final Uri uri = Uri.parse('$cleanBaseUrl/users/$username/bookmarks?page=$page');
      final http.Response resp =
          await client.get(uri, headers: _buildHeaders()).timeout(const Duration(seconds: 25));

      _mergeCookies(resp);

      if (resp.statusCode == 403) {
        return const Ao3Result.err('获取书签被 Cloudflare 拦截 (HTTP 403)');
      }

      if (resp.statusCode != 200) {
        return Ao3Result.err('获取书签失败 (HTTP ${resp.statusCode})');
      }

      final List<Work> works = parseWorksList(resp.body);
      return Ao3Result.ok(works);
    } catch (e) {
      return Ao3Result.err('获取书签失败: $e');
    } finally {
      client.close();
    }
  }

  // =========================================================================
  // 4. 获取作品全文与章节
  // =========================================================================
  Future<Ao3Result<Work>> fetchWorkFull(int workId) async {
    final http.Client client = _createClient();
    try {
      final Uri uri =
          Uri.parse('$cleanBaseUrl/works/$workId?view_adult=true&view_full_work=true');
      final http.Response resp =
          await client.get(uri, headers: _buildHeaders()).timeout(const Duration(seconds: 30));

      _mergeCookies(resp);

      if (resp.statusCode == 403) {
        return const Ao3Result.err('获取正文被 Cloudflare 拦截 (HTTP 403)');
      }

      if (resp.statusCode != 200) {
        return Ao3Result.err('获取正文失败 (HTTP ${resp.statusCode})');
      }

      final Work work = parseWorkDetailAndChapters(workId, resp.body);
      return Ao3Result.ok(work);
    } catch (e) {
      return Ao3Result.err('获取正文失败: $e');
    } finally {
      client.close();
    }
  }

  // =========================================================================
  // HTML 解析辅助函数
  // =========================================================================
  static List<Work> parseWorksList(String htmlContent) {
    final dom.Document doc = html_parser.parse(htmlContent);
    final List<dom.Element> blurbs = doc.querySelectorAll('li.work.blurb');
    final List<Work> list = <Work>[];

    for (final dom.Element blurb in blurbs) {
      final String rawId = blurb.attributes['id'] ?? '';
      final int id = int.tryParse(rawId.replaceAll('work_', '')) ??
          int.tryParse(blurb.querySelector('h4.heading a')?.attributes['href']?.replaceAll(RegExp(r'[^0-9]'), '') ?? '') ??
          0;
      if (id == 0) continue;

      final dom.Element? titleEl = blurb.querySelector('h4.heading a:first-child');
      final String title = titleEl?.text.trim() ?? 'Untitled';

      final dom.Element? authorEl = blurb.querySelector('h4.heading a[rel="author"]');
      final String author = authorEl?.text.trim() ?? 'Anonymous';

      final List<String> fandomList = blurb
          .querySelectorAll('h5.fandoms a.tag')
          .map((dom.Element e) => e.text.trim())
          .toList();
      final String fandom = fandomList.isEmpty ? 'General' : fandomList.join(', ');

      String rating = 'T';
      final dom.Element? ratingSpan = blurb.querySelector('span.rating');
      final String ratingClasses = ratingSpan?.classes.join(' ') ?? '';
      if (ratingClasses.contains('rating-general-audience')) {
        rating = 'G';
      } else if (ratingClasses.contains('rating-teen')) {
        rating = 'T';
      } else if (ratingClasses.contains('rating-mature')) {
        rating = 'M';
      } else if (ratingClasses.contains('rating-explicit')) {
        rating = 'E';
      }

      final List<String> warnings = blurb
          .querySelectorAll('ul.tags li.warnings a.tag')
          .map((dom.Element e) => e.text.trim())
          .toList();
      if (warnings.isEmpty) {
        final String? wTitle = blurb.querySelector('span.warnings')?.attributes['title'];
        if (wTitle != null && wTitle.isNotEmpty) {
          warnings.add(wTitle);
        }
      }

      final List<String> rels = blurb
          .querySelectorAll('ul.tags li.relationships a.tag')
          .map((dom.Element e) => e.text.trim())
          .toList();
      final String relationship = rels.join(', ');

      final List<String> tags = blurb
          .querySelectorAll('ul.tags li.freeforms a.tag, ul.tags li.characters a.tag')
          .map((dom.Element e) => e.text.trim())
          .toList();

      final dom.Element? sumEl = blurb.querySelector('blockquote.userstuff.summary');
      final String summary = sumEl?.text.trim() ?? '';

      final String words = blurb.querySelector('dd.words')?.text.trim() ?? '0';
      final String kudos = blurb.querySelector('dd.kudos a')?.text.trim() ??
          blurb.querySelector('dd.kudos')?.text.trim() ??
          '0';
      final String hits = blurb.querySelector('dd.hits')?.text.trim() ?? '0';

      final String chaptersStr = blurb.querySelector('dd.chapters')?.text.trim() ?? '1/1';
      final bool complete = !chaptersStr.endsWith('?');

      list.add(Work(
        id: id,
        title: title,
        titleZh: '',
        author: author,
        fandom: fandom,
        rating: rating,
        warnings: warnings,
        relationship: relationship,
        tags: tags,
        tagsZh: const <String>[],
        summary: summary,
        summaryZh: '',
        words: words,
        year: DateTime.now().year,
        kudos: kudos,
        hits: hits,
        complete: complete,
        zhReady: false,
        chapters: const <Chapter>[],
      ));
    }
    return list;
  }

  static Work parseWorkDetailAndChapters(int workId, String htmlContent) {
    final dom.Document doc = html_parser.parse(htmlContent);

    final String title = doc.querySelector('#workskin h2.title')?.text.trim() ??
        doc.querySelector('h2.title')?.text.trim() ??
        'Untitled';

    final String author = doc.querySelector('#workskin h3.byline a')?.text.trim() ??
        doc.querySelector('h3.byline a')?.text.trim() ??
        'Anonymous';

    final List<String> fandomList = doc
        .querySelectorAll('dd.fandom ul li a')
        .map((dom.Element e) => e.text.trim())
        .toList();
    final String fandom = fandomList.isEmpty ? 'General' : fandomList.join(', ');

    final String summary = doc.querySelector('#workskin .summary blockquote')?.text.trim() ??
        doc.querySelector('.summary blockquote')?.text.trim() ??
        '';

    final List<String> tags = doc
        .querySelectorAll('dd.freeform ul li a, dd.character ul li a')
        .map((dom.Element e) => e.text.trim())
        .toList();

    final List<String> rels = doc
        .querySelectorAll('dd.relationship ul li a')
        .map((dom.Element e) => e.text.trim())
        .toList();

    final String words = doc.querySelector('dd.words')?.text.trim() ?? '0';
    final String kudos = doc.querySelector('dd.kudos')?.text.trim() ?? '0';
    final String hits = doc.querySelector('dd.hits')?.text.trim() ?? '0';

    final List<Chapter> chapters = <Chapter>[];
    final List<dom.Element> chapterEls = doc.querySelectorAll('#chapters .chapter');

    if (chapterEls.isNotEmpty) {
      for (int i = 0; i < chapterEls.length; i++) {
        final dom.Element cEl = chapterEls[i];
        final String cTitle = cEl.querySelector('h3.title')?.text.trim() ?? '第 ${i + 1} 章';
        final List<Para> paras = <Para>[];

        final List<dom.Element> pEls = cEl.querySelectorAll('.userstuff p');
        for (final dom.Element p in pEls) {
          final String text = p.text.trim();
          if (text.isNotEmpty) {
            paras.add(Para(text, ''));
          }
        }
        if (paras.isNotEmpty) {
          chapters.add(Chapter(cTitle, paras));
        }
      }
    } else {
      final List<dom.Element> pEls = doc.querySelectorAll('#workskin div.userstuff p');
      final List<Para> paras = <Para>[];
      for (final dom.Element p in pEls) {
        final String text = p.text.trim();
        if (text.isNotEmpty) {
          paras.add(Para(text, ''));
        }
      }
      chapters.add(Chapter('正文', paras));
    }

    return Work(
      id: workId,
      title: title,
      titleZh: '',
      author: author,
      fandom: fandom,
      rating: 'T',
      warnings: const <String>[],
      relationship: rels.join(', '),
      tags: tags,
      tagsZh: const <String>[],
      summary: summary,
      summaryZh: '',
      words: words,
      year: DateTime.now().year,
      kudos: kudos,
      hits: hits,
      complete: true,
      zhReady: false,
      chapters: chapters,
    );
  }
}
