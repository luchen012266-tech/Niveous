import 'package:flutter/material.dart';

import '../app_state.dart';
import '../demo_data.dart';
import '../models.dart';
import '../palettes.dart';
import '../widgets/paper_scaffold.dart';
import '../widgets/proxy_dialog.dart';
import '../widgets/work_card.dart';
import 'ao3_webview_login.dart';
import 'detail_screen.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key, this.libraryOnly = false});

  final bool libraryOnly;

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final TextEditingController _q = TextEditingController();
  String _status = 'all';
  String _sort = 'kudos';
  bool _useOnline = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _triggerSearch(AppState s) {
    if (widget.libraryOnly) return;
    setState(() => _useOnline = true);
    s.searchAo3(query: _q.text.trim(), sort: _sort, status: _status);
  }

  List<Work> _filtered(AppState s) {
    List<Work> baseList;
    if (widget.libraryOnly) {
      final Set<int> bms = s.bookmarks;
      final List<Work> combined = <Work>[...s.onlineWorks, ...kDemoWorks];
      final Map<int, Work> map = <int, Work>{};
      for (final Work w in combined) {
        if (bms.contains(w.id)) {
          map[w.id] = w;
        }
      }
      baseList = map.values.toList();
    } else if (_useOnline && s.onlineWorks.isNotEmpty) {
      baseList = List<Work>.of(s.onlineWorks);
    } else {
      baseList = List<Work>.of(kDemoWorks);
    }

    final String q = _q.text.trim().toLowerCase();
    if (q.isNotEmpty && (!_useOnline || widget.libraryOnly)) {
      baseList = baseList.where((Work w) {
        final String blob = <String>[
          w.title,
          w.titleZh,
          w.author,
          w.fandom,
          ...w.tags,
          ...w.tagsZh,
        ].join(' ').toLowerCase();
        return blob.contains(q);
      }).toList();
    }

    switch (_status) {
      case 'done':
        baseList = baseList.where((Work w) => w.complete).toList();
      case 'wip':
        baseList = baseList.where((Work w) => !w.complete).toList();
      case 'zh':
        baseList = baseList.where((Work w) => w.zhReady).toList();
      case 'short':
        baseList = baseList
            .where((Work w) =>
                (int.tryParse(w.words.replaceAll(',', '')) ?? 0) < 10000)
            .toList();
    }

    int numVal(String v) => int.tryParse(v.replaceAll(',', '')) ?? 0;
    switch (_sort) {
      case 'kudos':
        baseList.sort((Work a, Work b) => numVal(b.kudos).compareTo(numVal(a.kudos)));
      case 'hits':
        baseList.sort((Work a, Work b) => numVal(b.hits).compareTo(numVal(a.hits)));
      case 'words':
        baseList.sort((Work a, Work b) => numVal(b.words).compareTo(numVal(a.words)));
      case 'new':
        baseList.sort((Work a, Work b) => b.year.compareTo(a.year));
    }
    return baseList;
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    final List<Work> works = _filtered(s);
    final bool isOnlineMode = _useOnline && s.onlineWorks.isNotEmpty;

    return Scaffold(
      body: PaperScaffold(
        child: SafeArea(
          bottom: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 12, 6),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Text(
                                widget.libraryOnly ? '书库' : '发现',
                                style: TextStyle(
                                  fontSize: 21,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'serif',
                                  color: p.ink,
                                ),
                              ),
                              const SizedBox(width: 8),
                              if (!widget.libraryOnly)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: isOnlineMode ? const Color(0xFF2E7D32).withOpacity(0.12) : s.accentSoft,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    isOnlineMode ? 'AO3 实时数据' : '演示数据',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      color: isOnlineMode ? const Color(0xFF2E7D32) : s.accent,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            widget.libraryOnly
                                ? '书库 · ${works.length} 篇收藏'
                                : (isOnlineMode
                                    ? '来自 AO3 · ${works.length} 篇作品'
                                    : '共 ${works.length} 篇作品 · 可输入关键词回车抓取真实 AO3'),
                            style: TextStyle(fontSize: 11.5, color: p.muted),
                          ),
                        ],
                      ),
                    ),
                    _IconBtn(
                      icon: Icons.language_outlined,
                      tooltip: 'AO3 网页嗅探与导入',
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => const Ao3WebViewLoginScreen(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _IconBtn(
                      icon: Icons.wifi_outlined,
                      tooltip: '网络与代理设置',
                      onTap: () => ProxyDialog.show(context),
                    ),
                    const SizedBox(width: 8),
                    _IconBtn(
                      icon: Icons.brightness_6_outlined,
                      tooltip: '切换深浅色',
                      onTap: () => s.setPaper(p.dark ? 'clear' : 'night'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: p.line),
                  ),
                  child: TextField(
                    controller: _q,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _triggerSearch(s),
                    style: TextStyle(fontSize: 14.5, color: p.ink),
                    decoration: InputDecoration(
                      isDense: true,
                      prefixIcon: Icon(Icons.search,
                          size: 18, color: p.muted.withOpacity(0.8)),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.arrow_forward, size: 18, color: s.accent),
                        tooltip: '在 AO3 实时搜索',
                        onPressed: () => _triggerSearch(s),
                      ),
                      hintText: '搜索 AO3（如 harry potter / slow burn）',
                      hintStyle: TextStyle(fontSize: 14, color: p.muted),
                      contentPadding:
                          const EdgeInsets.symmetric(vertical: 13),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
              _ChipRow(
                items: const <List<String>>[
                  <String>['all', '全部'],
                  <String>['done', '已完结'],
                  <String>['wip', '连载中'],
                  <String>['zh', '有中文译版'],
                  <String>['short', '短篇 < 1 万字'],
                ],
                active: _status,
                onPick: (String v) {
                  setState(() => _status = v);
                  if (_useOnline) _triggerSearch(s);
                },
              ),
              _ChipRow(
                items: const <List<String>>[
                  <String>['kudos', '按 kudos'],
                  <String>['hits', '按浏览量'],
                  <String>['words', '按字数'],
                  <String>['new', '最近更新'],
                ],
                active: _sort,
                onPick: (String v) {
                  setState(() => _sort = v);
                  if (_useOnline) _triggerSearch(s);
                },
                trailing: GestureDetector(
                  onTap: () => _triggerSearch(s),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 13, vertical: 7),
                    decoration: BoxDecoration(
                      color: s.accentSoft,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: s.accent),
                    ),
                    child: Text('抓取 AO3 实时榜单',
                        style:
                            TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: s.accent)),
                  ),
                ),
              ),
              if (s.searchError != null && !widget.libraryOnly)
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: s.accent.withOpacity(0.5)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Icon(Icons.shield_outlined, size: 16, color: s.accent),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              '${s.searchError}\n(已自动展示本地数据)',
                              style: TextStyle(fontSize: 12, height: 1.5, color: p.ink2),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          TextButton(
                            onPressed: () => ProxyDialog.show(context),
                            child: Text('网络设置', style: TextStyle(fontSize: 12, color: p.ink2)),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton.icon(
                            onPressed: () async {
                              final res = await Navigator.of(context).push<bool>(
                                MaterialPageRoute<bool>(
                                  builder: (_) => const Ao3WebViewLoginScreen(),
                                ),
                              );
                              if (res == true) {
                                // If imported works directly, onlineWorks is already set!
                                if (s.onlineWorks.isEmpty) {
                                  _triggerSearch(s);
                                }
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: s.accent,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            icon: const Icon(Icons.travel_explore, size: 14),
                            label: const Text('过盾 / 网页一键导入', style: TextStyle(fontSize: 12)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              Expanded(
                child: s.isSearching
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            CircularProgressIndicator(color: s.accent, strokeWidth: 2.2),
                            const SizedBox(height: 14),
                            Text('正在从 AO3 实时抓取作品列表...', style: TextStyle(fontSize: 13, color: p.muted)),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        color: s.accent,
                        onRefresh: () async {
                          if (widget.libraryOnly) {
                            await s.loadBookmarks();
                          } else {
                            await s.searchAo3(query: _q.text.trim(), sort: _sort, status: _status);
                            setState(() => _useOnline = true);
                          }
                        },
                        child: works.isEmpty
                            ? ListView(
                                children: <Widget>[
                                  SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                                  Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: <Widget>[
                                        Icon(Icons.menu_book_outlined,
                                            size: 38,
                                            color: p.muted.withOpacity(0.5)),
                                        const SizedBox(height: 10),
                                        Text(
                                          widget.libraryOnly
                                              ? '书库还是空的\n在作品卡片上点书签图标收藏'
                                              : '没有匹配的作品，可尝试开启代理后搜索',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 13,
                                              height: 1.9,
                                              color: p.muted),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 2, 16, 24),
                                itemCount: works.length,
                                itemBuilder: (BuildContext c, int i) {
                                  final Work w = works[i];
                                  return WorkCard(
                                    work: w,
                                    bookmarked: s.bookmarks.contains(w.id),
                                    onBookmark: () => s.toggleBookmark(w.id),
                                    onOpen: () => Navigator.of(context).push(
                                      MaterialPageRoute<void>(
                                        builder: (_) => DetailScreen(work: w),
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChipRow extends StatelessWidget {
  const _ChipRow({
    required this.items,
    required this.active,
    required this.onPick,
    this.trailing,
  });

  final List<List<String>> items;
  final String active;
  final ValueChanged<String> onPick;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
        children: <Widget>[
          ...items.map((List<String> it) {
            final bool on = active == it[0];
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => onPick(it[0]),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                  decoration: BoxDecoration(
                    color: on ? s.accent : p.card,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: on ? s.accent : p.line),
                  ),
                  child: Text(
                    it[1],
                    style: TextStyle(
                      fontSize: 12.5,
                      color: on ? Colors.white : p.ink2,
                      fontWeight: on ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ),
            );
          }),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  const _IconBtn({
    required this.icon,
    required this.onTap,
    this.tooltip = '',
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    final Palette p = AppScope.of(context).palette;
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: p.line),
          ),
          child: Icon(icon, size: 18, color: p.ink2),
        ),
      ),
    );
  }
}
