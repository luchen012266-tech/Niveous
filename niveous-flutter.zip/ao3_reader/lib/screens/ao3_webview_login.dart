import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../ao3_client.dart';
import '../app_state.dart';
import '../cookie_helper.dart';
import '../models.dart';
import '../palettes.dart';
import 'reader_screen.dart';

/// AO3 官方网页浏览、安全登录与一键抓取导入
class Ao3WebViewLoginScreen extends StatefulWidget {
  const Ao3WebViewLoginScreen({super.key, this.initialUrl});

  final String? initialUrl;

  @override
  State<Ao3WebViewLoginScreen> createState() => _Ao3WebViewLoginScreenState();
}

class _Ao3WebViewLoginScreenState extends State<Ao3WebViewLoginScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  double _progress = 0;
  bool _handled = false;
  String _currentUrl = '';
  int _worksCountOnPage = 0;
  bool _isWorkPage = false;
  int _currentWorkId = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initWebView());
  }

  void _initWebView() {
    final AppState s = AppScope.of(context);
    final String base = s.ao3BaseUrl.endsWith('/')
        ? s.ao3BaseUrl.substring(0, s.ao3BaseUrl.length - 1)
        : s.ao3BaseUrl;
    final String startUrl = widget.initialUrl ?? '$base/works/search';
    _currentUrl = startUrl;

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(Ao3Client.defaultUserAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) setState(() => _progress = progress / 100.0);
          },
          onPageStarted: (String url) {
            if (mounted) {
              setState(() {
                _loading = true;
                _currentUrl = url;
              });
            }
            _checkLoginSuccess(url);
          },
          onPageFinished: (String url) {
            if (mounted) {
              setState(() {
                _loading = false;
                _currentUrl = url;
              });
            }
            _checkLoginSuccess(url);
            _detectPageContent();
          },
          onWebResourceError: (WebResourceError error) {
            if (mounted) setState(() => _loading = false);
          },
        ),
      )
      ..loadRequest(Uri.parse(startUrl));
  }

  Future<void> _checkLoginSuccess(String url) async {
    if (_handled) return;
    final Uri? uri = Uri.tryParse(url);
    if (uri == null) return;

    // AO3 登录成功通常重定向到 /users/<username>
    if (url.contains('/users/') &&
        !url.contains('/users/login') &&
        !url.contains('/users/new') &&
        !url.contains('/users/password')) {
      _handled = true;
      final List<String> segments = uri.pathSegments;
      final int idx = segments.indexOf('users');
      String username = '';
      if (idx >= 0 && segments.length > idx + 1) {
        username = segments[idx + 1];
      }

      // 获取包含 HttpOnly 的全部原生 Cookie (包括 _otwarchive_session 和 cf_clearance)
      String cookieHeader = await NativeCookieHelper.getCookies(url);
      if (cookieHeader.isEmpty) {
        cookieHeader = await NativeCookieHelper.getCookies('https://archiveofourown.org');
      }

      if (mounted) {
        final AppState s = AppScope.of(context);
        s.setAo3Session(
          username.isNotEmpty ? username : 'AO3用户',
          cookieHeader,
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('登录成功！欢迎回来，${s.userName}'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> _detectPageContent() async {
    try {
      final Object countRes = await _controller.runJavaScriptReturningResult(
          "document.querySelectorAll('li.work.blurb').length.toString()");
      final int count = int.tryParse(countRes.toString().replaceAll('"', '')) ?? 0;

      final Object isWorkRes = await _controller.runJavaScriptReturningResult(
          "(window.location.href.indexOf('/works/') > 0 && window.location.href.indexOf('/works/search') < 0) ? '1' : '0'");
      final bool isWork = isWorkRes.toString().replaceAll('"', '') == '1';

      int workId = 0;
      if (isWork) {
        final Object idRes = await _controller.runJavaScriptReturningResult(
            "(window.location.pathname.match(/\\/works\\/(\\d+)/) || [])[1] || '0'");
        workId = int.tryParse(idRes.toString().replaceAll('"', '')) ?? 0;
      }

      if (mounted) {
        setState(() {
          _worksCountOnPage = count;
          _isWorkPage = isWork && workId > 0;
          _currentWorkId = workId;
        });
      }
    } catch (_) {}
  }

  Future<String> _getPageHtml() async {
    final Object raw = await _controller
        .runJavaScriptReturningResult('document.documentElement.outerHTML');
    String html = raw.toString();
    if (html.startsWith('"') && html.endsWith('"')) {
      try {
        html = jsonDecode(html) as String;
      } catch (_) {
        html = html.substring(1, html.length - 1).replaceAll(r'\"', '"').replaceAll(r'\n', '\n');
      }
    }
    return html;
  }

  /// 导入本页所有作品到发现列表
  Future<void> _importWorksToList() async {
    try {
      final String html = await _getPageHtml();
      final List<Work> works = Ao3Client.parseWorksList(html);
      if (works.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('未能从当前网页中检测到作品卡片，请尝试翻页或搜索')),
          );
        }
        return;
      }

      if (mounted) {
        final AppState s = AppScope.of(context);
        s.setOnlineWorks(works);

        // 同时保存 Cookie
        final String cookies = await NativeCookieHelper.getCookies(_currentUrl);
        if (cookies.isNotEmpty) {
          s.setAo3Session(s.userName, cookies);
        }
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🎉 成功导入 ${works.length} 篇作品到发现页！'),
            duration: const Duration(seconds: 2),
          ),
        );
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('抓取失败: $e')),
        );
      }
    }
  }

  /// 导入当前作品直接进入排版阅读器
  Future<void> _importCurrentWorkToReader() async {
    if (_currentWorkId <= 0) return;
    try {
      final String html = await _getPageHtml();
      final Work work = Ao3Client.parseWorkDetailAndChapters(_currentWorkId, html);

      if (work.chapters.isEmpty || work.chapters.first.paragraphs.isEmpty) {
        if (!mounted) return;
        final AppState s = AppScope.of(context);
        final String fullUrl = '${s.ao3BaseUrl}/works/$_currentWorkId?view_adult=true&view_full_work=true';
        await _controller.loadRequest(Uri.parse(fullUrl));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('正在自动载入全本内容，请稍候片刻再点击导入...')),
          );
        }
        return;
      }

      if (mounted) {
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ReaderScreen(
              work: work,
              chapterIndex: 0,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('解析正文失败: $e')),
        );
      }
    }
  }

  Future<void> _manualSyncCookie() async {
    final AppState s = AppScope.of(context);
    final String url = _currentUrl.isNotEmpty ? _currentUrl : s.ao3BaseUrl;
    String cookieHeader = await NativeCookieHelper.getCookies(url);
    if (cookieHeader.isEmpty) {
      cookieHeader = await NativeCookieHelper.getCookies('https://archiveofourown.org');
    }

    if (cookieHeader.isNotEmpty) {
      s.setAo3Session(s.userName, cookieHeader);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ 凭据已成功同步至 App 本地'),
            duration: Duration(seconds: 2),
          ),
        );
        Navigator.of(context).pop(true);
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('未检测到有效凭据，请先在页面中通过验证或登录')),
        );
      }
    }
  }

  void _loadShortcut(String url) {
    _controller.loadRequest(Uri.parse(url));
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: p.card,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.close, color: p.ink),
          onPressed: () => Navigator.of(context).pop(false),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              'AO3 网页嗅探与导入',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: p.ink,
              ),
            ),
            Text(
              _currentUrl.replaceAll('https://', '').replaceAll('http://', ''),
              style: TextStyle(fontSize: 10, color: p.muted),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.refresh, color: p.ink2),
            onPressed: () => _controller.reload(),
          ),
          PopupMenuButton<String>(
            icon: Icon(Icons.bookmarks_outlined, color: s.accent),
            tooltip: '快捷入口',
            onSelected: _loadShortcut,
            itemBuilder: (BuildContext ctx) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'https://archiveofourown.org/works/search',
                child: Text('🔍 AO3 官方搜索'),
              ),
              const PopupMenuItem<String>(
                value: 'https://archiveofourown.org',
                child: Text('🚀 AO3 官方主站'),
              ),
              const PopupMenuItem<String>(
                value: 'https://archiveofourown.org/users/login',
                child: Text('👤 官方登录入口'),
              ),
              if (s.loggedIn && s.userName.isNotEmpty && s.userName != '访客')
                PopupMenuItem<String>(
                  value: 'https://archiveofourown.org/users/${s.userName}/bookmarks',
                  child: Text('🔖 我的书签 (${s.userName})'),
                ),
              const PopupMenuDivider(),
              const PopupMenuItem<String>(
                value: 'https://nightskies.top/works/search',
                child: Text('🌐 镜像源 1 (nightskies)'),
              ),
              const PopupMenuItem<String>(
                value: 'https://ao3.org',
                child: Text('🌐 镜像源 2 (ao3.org)'),
              ),
            ],
          ),
        ],
        bottom: _loading
            ? PreferredSize(
                preferredSize: const Size.fromHeight(2),
                child: LinearProgressIndicator(
                  value: _progress > 0 ? _progress : null,
                  color: s.accent,
                  backgroundColor: Colors.transparent,
                ),
              )
            : null,
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            color: s.accentSoft,
            child: Row(
              children: <Widget>[
                Icon(Icons.shield_outlined, size: 15, color: s.accent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '若提示验证，请轻触网页方框；通过后可直接在底部一键导入作品。',
                    style: TextStyle(fontSize: 11, color: s.accent, height: 1.3),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: WebViewWidget(controller: _controller),
          ),
          // 底部智能操作栏
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: p.card,
              border: Border(top: BorderSide(color: p.line)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 6,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: <Widget>[
                  if (_isWorkPage) ...<Widget>[
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.menu_book, size: 16),
                        label: const Text('📖 进入 Niveous 排版阅读'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: s.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: _importCurrentWorkToReader,
                      ),
                    ),
                    const SizedBox(width: 8),
                  ] else if (_worksCountOnPage > 0) ...<Widget>[
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.download, size: 16),
                        label: Text('📥 导入本页作品 ($_worksCountOnPage 篇)'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: s.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: _importWorksToList,
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  OutlinedButton(
                    onPressed: _manualSyncCookie,
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: p.line),
                      foregroundColor: p.ink,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('同步凭证'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
