import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../ao3_client.dart';
import '../app_state.dart';
import '../cookie_helper.dart';
import '../palettes.dart';

/// AO3 官方网页登录与过盾（支持 Cloudflare 人机验证与验证码）
class Ao3WebViewLoginScreen extends StatefulWidget {
  const Ao3WebViewLoginScreen({super.key});

  @override
  State<Ao3WebViewLoginScreen> createState() => _Ao3WebViewLoginScreenState();
}

class _Ao3WebViewLoginScreenState extends State<Ao3WebViewLoginScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  double _progress = 0;
  bool _handled = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initWebView());
  }

  void _initWebView() {
    final AppState s = AppScope.of(context);
    final String base = s.ao3BaseUrl.endsWith('/')
        ? s.ao3BaseUrl.substring(0, s.ao3BaseUrl.length - 1)
        : s.ao3BaseUrl;
    final String url = '$base/users/login';

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(Ao3Client.defaultUserAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) setState(() => _progress = progress / 100.0);
          },
          onPageStarted: (String url) {
            if (mounted) setState(() => _loading = true);
            _checkLoginSuccess(url);
          },
          onPageFinished: (String url) {
            if (mounted) setState(() => _loading = false);
            _checkLoginSuccess(url);
          },
          onWebResourceError: (WebResourceError error) {
            if (mounted) setState(() => _loading = false);
          },
        ),
      )
      ..loadRequest(Uri.parse(url));
  }

  Future<void> _checkLoginSuccess(String url) async {
    if (_handled) return;
    final Uri? uri = Uri.tryParse(url);
    if (uri == null) return;

    // AO3 登录成功通常重定向到 /users/<username>
    if (url.contains('/users/') &&
        !url.contains('/users/login') &&
        !url.contains('/users/new') &&
        !url.contains('/users/password')) {
      _handled = true;
      final List<String> segments = uri.pathSegments;
      final int idx = segments.indexOf('users');
      String username = '';
      if (idx >= 0 && segments.length > idx + 1) {
        username = segments[idx + 1];
      }

      // 获取包含 HttpOnly 的全部原生 Cookie (包括 _otwarchive_session 和 cf_clearance)
      String cookieHeader = await NativeCookieHelper.getCookies(url);
      if (cookieHeader.isEmpty) {
        cookieHeader = await NativeCookieHelper.getCookies('https://archiveofourown.org');
      }

      if (cookieHeader.isEmpty) {
        try {
          final Object raw =
              await _controller.runJavaScriptReturningResult('document.cookie');
          cookieHeader = raw.toString();
          if (cookieHeader.startsWith('"') && cookieHeader.endsWith('"')) {
            cookieHeader = cookieHeader.substring(1, cookieHeader.length - 1);
          }
        } catch (_) {}
      }

      if (mounted) {
        final AppState s = AppScope.of(context);
        s.setAo3Session(
          username.isNotEmpty ? username : 'AO3用户',
          cookieHeader,
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('登录成功！欢迎回来，${s.userName}'),
            duration: const Duration(seconds: 2),
          ),
        );
        Navigator.of(context).pop(true);
      }
    }
  }

  Future<void> _manualFinish() async {
    final AppState s = AppScope.of(context);
    final String base = s.ao3BaseUrl;
    String cookieHeader = await NativeCookieHelper.getCookies(base);
    if (cookieHeader.isEmpty) {
      cookieHeader = await NativeCookieHelper.getCookies('https://archiveofourown.org');
    }
    if (cookieHeader.isEmpty) {
      try {
        final Object raw =
            await _controller.runJavaScriptReturningResult('document.cookie');
        cookieHeader = raw.toString();
        if (cookieHeader.startsWith('"') && cookieHeader.endsWith('"')) {
          cookieHeader = cookieHeader.substring(1, cookieHeader.length - 1);
        }
      } catch (_) {}
    }

    if (cookieHeader.isNotEmpty && cookieHeader != 'null') {
      s.setAo3Session(s.userName, cookieHeader);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('已成功保存过盾与登录凭证，正在返回刷新数据...'),
          duration: Duration(seconds: 2),
        ),
      );
      Navigator.of(context).pop(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: p.card,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.close, color: p.ink),
          onPressed: () => Navigator.of(context).pop(false),
        ),
        title: Text(
          'AO3 网页登录与过盾',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            fontFamily: 'serif',
            color: p.ink,
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.refresh, color: p.ink2),
            onPressed: () => _controller.reload(),
          ),
        ],
        bottom: _loading
            ? PreferredSize(
                preferredSize: const Size.fromHeight(2),
                child: LinearProgressIndicator(
                  value: _progress > 0 ? _progress : null,
                  color: s.accent,
                  backgroundColor: Colors.transparent,
                ),
              )
            : null,
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            color: s.accentSoft,
            child: Row(
              children: <Widget>[
                Icon(Icons.shield_outlined, size: 16, color: s.accent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '如果出现“Shields are up!”，请直接点击网页中的小方框完成验证。',
                    style: TextStyle(fontSize: 11.5, color: s.accent, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: WebViewWidget(controller: _controller),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: p.card,
              border: Border(top: BorderSide(color: p.line)),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    '验证成功或已完成登录：',
                    style: TextStyle(fontSize: 12, color: p.muted),
                  ),
                ),
                ElevatedButton(
                  onPressed: _manualFinish,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: s.accent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: const Text('完成验证，返回 App'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
