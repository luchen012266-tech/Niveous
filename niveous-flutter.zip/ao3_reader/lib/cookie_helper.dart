import 'package:flutter/services.dart';

class NativeCookieHelper {
  static const MethodChannel _channel =
      MethodChannel('com.archivereader.ao3_reader/cookies');

  /// 获取指定 URL 下的全部 Cookie（包括 HttpOnly 类型的 session 和 cf_clearance）
  static Future<String> getCookies(String url) async {
    try {
      final String? cookies = await _channel.invokeMethod<String>(
        'getCookies',
        <String, dynamic>{'url': url},
      );
      return cookies ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> setCookie(String url, String cookie) async {
    try {
      await _channel.invokeMethod<bool>(
        'setCookie',
        <String, dynamic>{'url': url, 'cookie': cookie},
      );
    } catch (_) {}
  }
}
