(function() {
  if (window.__niveousEnhancerLoaded) {
    if (window.__niveousApply) window.__niveousApply();
    return;
  }
  window.__niveousEnhancerLoaded = true;

  const ZH_DICT = {
    "Fandoms": "同人圈",
    "Browse": "浏览",
    "Search": "搜索",
    "About": "关于",
    "Log In": "登录",
    "Log Out": "退出",
    "Hi,": "你好，",
    "My Dashboard": "个人主页",
    "Bookmarks": "书签",
    "History": "阅读历史",
    "Subscriptions": "我的订阅",
    "Works": "作品",
    "Drafts": "草稿",
    "Preferences": "偏好设置",
    "Skins": "界面皮肤",
    "Entire Work": "全文模式",
    "Chapter by Chapter": "分章模式",
    "Chapter Index": "章节目录",
    "Next Chapter →": "下一章 →",
    "← Previous Chapter": "← 上一章",
    "Kudos ♥": "点赞 ♥",
    "Kudos": "点赞",
    "Bookmark": "加入书签",
    "Subscribe": "订阅更新",
    "Download": "下载",
    "Comments": "评论",
    "Share": "分享",
    "Rating:": "分级：",
    "Archive Warning:": "警告：",
    "Archive Warnings:": "警告：",
    "Category:": "性向：",
    "Categories:": "性向：",
    "Fandom:": "原作：",
    "Fandoms:": "原作：",
    "Relationship:": "配对：",
    "Relationships:": "配对：",
    "Character:": "角色：",
    "Characters:": "角色：",
    "Additional Tags:": "标签：",
    "Language:": "语言：",
    "Stats:": "统计：",
    "Published:": "发布：",
    "Updated:": "更新：",
    "Completed:": "完结：",
    "Words:": "字数：",
    "Chapters:": "章节：",
    "Hits:": "阅读量：",
    "Sort and Filter": "排序与筛选",
    "Include": "包含标签",
    "Exclude": "排除标签",
    "Work Search": "作品搜索",
    "People Search": "作者搜索",
    "Bookmark Search": "书签搜索",
    "Top": "回到顶部"
  };

  function injectCSS() {
    let el = document.getElementById("__niveous_style");
    if (!el) {
      el = document.createElement("style");
      el.id = "__niveous_style";
      (document.head || document.documentElement).appendChild(el);
    }
    el.textContent = `
      /* Niveous 清爽美化样式 */
      body {
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Segoe UI", Roboto, sans-serif !important;
        -webkit-font-smoothing: antialiased;
        padding-bottom: 70px !important;
      }
      
      /* 隐藏横幅广告与冗杂元素 */
      #greeting, .announcement, .notice, #footer {
        display: none !important;
      }

      /* 头部导航美化 */
      #header {
        background: #FFFFFF !important;
        border-bottom: 1px solid #EBE7DF !important;
        box-shadow: 0 2px 10px rgba(0,0,0,0.03) !important;
      }
      #header a {
        color: #2D2833 !important;
      }
      #header .primary {
        background: transparent !important;
      }

      /* 作品卡片流美化 (Blurbs) */
      ol.work.index.group, ul.index.group {
        padding: 10px 12px !important;
      }
      li.work.blurb.group, li.bookmark.blurb.group {
        background: #FFFFFF !important;
        border-radius: 16px !important;
        border: 1px solid #EAE5DC !important;
        padding: 16px !important;
        margin: 12px 0 !important;
        box-shadow: 0 4px 16px rgba(45, 30, 20, 0.04) !important;
      }
      li.work.blurb.group .header h4.heading a:first-child {
        font-size: 17px !important;
        font-weight: 700 !important;
        color: #D35400 !important;
      }

      /* 标签胶囊化 */
      ul.tags li a.tag {
        background: #F5F1E9 !important;
        color: #6E6259 !important;
        border-radius: 6px !important;
        padding: 3px 8px !important;
        font-size: 11.5px !important;
        border: none !important;
        margin: 2px !important;
        display: inline-block !important;
      }

      /* 标签与简介智能折叠 */
      li.work.blurb.group:not(.__nv_expanded) ul.tags.commas {
        display: -webkit-box !important;
        -webkit-line-clamp: 2 !important;
        -webkit-box-orient: vertical !important;
        overflow: hidden !important;
        max-height: 3.2em !important;
      }
      li.work.blurb.group:not(.__nv_expanded) blockquote.userstuff.summary {
        display: -webkit-box !important;
        -webkit-line-clamp: 2 !important;
        -webkit-box-orient: vertical !important;
        overflow: hidden !important;
        max-height: 3.2em !important;
        margin-top: 8px !important;
      }

      .__nv_toggle_btn {
        margin-top: 8px;
        padding: 5px 10px;
        border-radius: 999px;
        background: #FBF8F2;
        border: 1px solid #EBE5DC;
        color: #D35400;
        font-size: 11px;
        font-weight: 600;
        text-align: center;
        cursor: pointer;
        user-select: none;
      }

      /* 正文页美化 */
      #workskin {
        background: #FFFFFF !important;
        border-radius: 18px !important;
        padding: 20px 16px !important;
        margin: 12px 8px !important;
        box-shadow: 0 4px 20px rgba(0,0,0,0.03) !important;
      }
      #chapters, div.userstuff {
        font-size: 17px !important;
        line-height: 1.85 !important;
        color: #2D2833 !important;
      }
      div.userstuff p {
        margin-bottom: 1.2em !important;
        text-indent: 2em !important;
      }
    `;
  }

  function enhanceCards() {
    const blurbs = document.querySelectorAll("li.work.blurb.group, li.bookmark.blurb.group");
    blurbs.forEach(card => {
      if (card.querySelector(".__nv_toggle_btn")) return;
      const toggle = document.createElement("div");
      toggle.className = "__nv_toggle_btn";
      toggle.textContent = "展开全部标签与简介 ▾";
      toggle.addEventListener("click", function(e) {
        e.stopPropagation();
        const expanded = card.classList.toggle("__nv_expanded");
        toggle.textContent = expanded ? "收起部分标签 ▴" : "展开全部标签与简介 ▾";
      });
      card.appendChild(toggle);
    });
  }

  function translate() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      const raw = node.nodeValue.trim();
      if (ZH_DICT[raw]) {
        node.nodeValue = node.nodeValue.replace(raw, ZH_DICT[raw]);
      }
    }
  }

  function apply() {
    injectCSS();
    enhanceCards();
    translate();
  }

  window.__niveousApply = apply;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", apply);
  } else {
    apply();
  }
})();
