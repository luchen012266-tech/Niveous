/// 数据模型
library;

class Para {
  final String en;
  final String zh;
  const Para(this.en, this.zh);
}

class Chapter {
  final String title;
  final List<Para> paragraphs;
  const Chapter(this.title, this.paragraphs);
}

class Work {
  final int id;
  final String title;
  final String titleZh;
  final String author;
  final String fandom;
  final String rating; // G / T / M / E
  final List<String> warnings;
  final String relationship;
  final List<String> tags;
  final List<String> tagsZh;
  final String summary;
  final String summaryZh;
  final String words;
  final int year;
  final String dateStr; // 纯阿拉伯数字日期，例如 2024.03.15
  final String kudos;
  final String hits;
  final bool complete;
  final bool zhReady;
  final List<Chapter> chapters;

  const Work({
    required this.id,
    required this.title,
    required this.titleZh,
    required this.author,
    required this.fandom,
    required this.rating,
    required this.warnings,
    required this.relationship,
    required this.tags,
    required this.tagsZh,
    required this.summary,
    required this.summaryZh,
    required this.words,
    required this.year,
    this.dateStr = '',
    required this.kudos,
    required this.hits,
    required this.complete,
    required this.zhReady,
    required this.chapters,
  });

  String get displayTitle => titleZh.isEmpty ? title : titleZh;
  bool get hasZhTitle => titleZh.isNotEmpty && titleZh != title;
  int get chapterCount => chapters.length;

  /// 纯阿拉伯数字日期显示
  String get displayArabicDate {
    if (dateStr.isNotEmpty) return formatArabicDate(dateStr);
    if (year > 1900) return '$year';
    return '';
  }

  static String formatArabicDate(String raw) {
    if (raw.trim().isEmpty) return '';
    final RegExp iso = RegExp(r'(\d{4})[-\.\/](\d{1,2})[-\.\/](\d{1,2})');
    final Match? mIso = iso.firstMatch(raw);
    if (mIso != null) {
      final String y = mIso.group(1)!;
      final String m = mIso.group(2)!.padLeft(2, '0');
      final String d = mIso.group(3)!.padLeft(2, '0');
      return '$y.$m.$d';
    }
    const Map<String, String> months = <String, String>{
      'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
      'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
      'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
    };
    final RegExp mmy = RegExp(r'(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})');
    final Match? mText = mmy.firstMatch(raw);
    if (mText != null) {
      final String d = mText.group(1)!.padLeft(2, '0');
      final String monName = mText.group(2)!.toLowerCase().substring(0, 3);
      final String m = months[monName] ?? '01';
      final String y = mText.group(3)!;
      return '$y.$m.$d';
    }
    return raw;
  }
}

/// AO3 分级对应的颜色
const Map<String, int> kRatingColors = <String, int>{
  'G': 0xFF2E7D32,
  'T': 0xFFE0930C,
  'M': 0xFFE2661A,
  'E': 0xFFB3261E,
};
