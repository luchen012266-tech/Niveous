import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../ao3_client.dart';
import '../app_state.dart';
import '../cookie_helper.dart';
import '../models.dart';
import '../palettes.dart';
import 'reader_screen.dart';

/// AO3 直通门户（结合 Kaelis 的即开即用便利性 + Niveous 的精美视觉与排版阅读器）
class Ao3PortalScreen extends StatefulWidget {
  const Ao3PortalScreen({super.key});

  @override
  State<Ao3PortalScreen> createState() => _Ao3PortalScreenState();
}

class _Ao3PortalScreenState extends State<Ao3PortalScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  double _progress = 0;
  String _currentUrl = 'https://archiveofourown.org/';
  bool _canGoBack = false;

  // 页面侦测状态
  bool _isWorkPage = false;
  int _currentWorkId = 0;
  int _worksCountOnPage = 0;
  bool _extracting = false;

  String? _enhancerScript;

  @override
  void initState() {
    super.initState();
    _loadScriptAsset();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initWebView());
  }

  Future<void> _loadScriptAsset() async {
    try {
      _enhancerScript =
          await rootBundle.loadString('assets/ao3_niveous_enhancer.js');
    } catch (_) {}
  }

  void _initWebView() {
    final AppState s = AppScope.of(context);
    final String base = s.ao3BaseUrl.endsWith('/')
        ? s.ao3BaseUrl.substring(0, s.ao3BaseUrl.length - 1)
        : s.ao3BaseUrl;
    _currentUrl = base;

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(Ao3Client.defaultUserAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) setState(() => _progress = progress / 100.0);
          },
          onPageStarted: (String url) {
            if (mounted) {
              setState(() {
                _loading = true;
                _currentUrl = url;
              });
            }
            _injectEnhancer();
            _checkAndUpdateStatus(url);
          },
          onPageFinished: (String url) {
            if (mounted) {
              setState(() {
                _loading = false;
                _currentUrl = url;
              });
            }
            _injectEnhancer();
            _checkAndUpdateStatus(url);
            _detectPageContent();
            _updateNavState();
          },
        ),
      )
      ..loadRequest(Uri.parse(base));
  }

  Future<void> _updateNavState() async {
    final bool back = await _controller.canGoBack();
    if (mounted) {
      setState(() {
        _canGoBack = back;
      });
    }
  }

  Future<void> _injectEnhancer() async {
    if (_enhancerScript != null && _enhancerScript!.isNotEmpty) {
      try {
        await _controller.runJavaScript(_enhancerScript!);
      } catch (_) {}
    }
  }

  Future<void> _checkAndUpdateStatus(String url) async {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null) return;

    // 自动同步底层原生 Cookie (包含 HttpOnly)
    try {
      final String cookies = await NativeCookieHelper.getCookies(url);
      if (cookies.isNotEmpty && mounted) {
        final AppState s = AppScope.of(context);
        if (url.contains('/users/') &&
            !url.contains('/users/login') &&
            !url.contains('/users/new')) {
          final List<String> segments = uri.pathSegments;
          final int idx = segments.indexOf('users');
          if (idx >= 0 && segments.length > idx + 1) {
            final String u = segments[idx + 1];
            s.setAo3Session(u, cookies);
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _detectPageContent() async {
    try {
      final Object countRes = await _controller.runJavaScriptReturningResult(
          "document.querySelectorAll('li.work.blurb').length.toString()");
      final int count = int.tryParse(countRes.toString().replaceAll('"', '')) ?? 0;

      final Object isWorkRes = await _controller.runJavaScriptReturningResult(
          "(window.location.href.indexOf('/works/') > 0 && window.location.href.indexOf('/works/search') < 0) ? '1' : '0'");
      final bool isWork = isWorkRes.toString().replaceAll('"', '') == '1';

      int workId = 0;
      if (isWork) {
        final Object idRes = await _controller.runJavaScriptReturningResult(
            "(window.location.pathname.match(/\\/works\\/(\\d+)/) || [])[1] || '0'");
        workId = int.tryParse(idRes.toString().replaceAll('"', '')) ?? 0;
      }

      if (mounted) {
        setState(() {
          _worksCountOnPage = count;
          _isWorkPage = isWork && workId > 0;
          _currentWorkId = workId;
        });
      }
    } catch (_) {}
  }

  Future<String> _getPageHtml() async {
    final Object raw = await _controller
        .runJavaScriptReturningResult('document.documentElement.outerHTML');
    String html = raw.toString();
    if (html.startsWith('"') && html.endsWith('"')) {
      try {
        html = jsonDecode(html) as String;
      } catch (_) {
        html = html
            .substring(1, html.length - 1)
            .replaceAll(r'\"', '"')
            .replaceAll(r'\n', '\n');
      }
    }
    return html;
  }

  /// 一键以 Niveous 精美排版模式阅读
  Future<void> _openInNiveousReader() async {
    if (_currentWorkId <= 0 || _extracting) return;
    setState(() => _extracting = true);

    try {
      // 检查当前是否是全文模式，如果不是，尝试加载全文视图
      if (!_currentUrl.contains('view_full_work=true')) {
        final AppState s = AppScope.of(context);
        final String base = s.ao3BaseUrl.endsWith('/')
            ? s.ao3BaseUrl.substring(0, s.ao3BaseUrl.length - 1)
            : s.ao3BaseUrl;
        final String fullUrl =
            '$base/works/$_currentWorkId?view_adult=true&view_full_work=true';
        await _controller.loadRequest(Uri.parse(fullUrl));
        // 给 1.5 秒加载全文
        await Future<void>.delayed(const Duration(milliseconds: 1500));
      }

      final String html = await _getPageHtml();
      final Work work =
          Ao3Client.parseWorkDetailAndChapters(_currentWorkId, html);

      setState(() => _extracting = false);

      if (work.chapters.isEmpty || work.chapters.first.paragraphs.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('正在载入章节内容，请在页面完全加载后再点击...')),
          );
        }
        return;
      }

      if (mounted) {
        // 自动加入书签收藏
        final AppState s = AppScope.of(context);
        s.toggleBookmark(work.id);

        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ReaderScreen(
              work: work,
              chapterIndex: 0,
            ),
          ),
        );
      }
    } catch (e) {
      setState(() => _extracting = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('解析正文失败: $e')),
        );
      }
    }
  }

  /// 批量收藏/保存当前页作品
  Future<void> _saveWorksToLibrary() async {
    try {
      final String html = await _getPageHtml();
      final List<Work> works = Ao3Client.parseWorksList(html);
      if (works.isEmpty) return;

      if (mounted) {
        final AppState s = AppScope.of(context);
        s.setOnlineWorks(works);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🎉 已同步 ${works.length} 篇作品至【书库】！'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (_) {}
  }

  void _switchSource(String url) {
    final AppState s = AppScope.of(context);
    s.setBaseUrl(url);
    _controller.loadRequest(Uri.parse(url));
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    return Scaffold(
      backgroundColor: p.paper,
      appBar: AppBar(
        backgroundColor: p.card,
        elevation: 0,
        leading: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.arrow_back_ios_new,
                  size: 18, color: _canGoBack ? p.ink : p.muted.withOpacity(0.4)),
              onPressed: _canGoBack ? () => _controller.goBack() : null,
            ),
          ],
        ),
        titleSpacing: 0,
        title: Container(
          height: 36,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: p.paper,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: p.line),
          ),
          child: Row(
            children: <Widget>[
              Icon(Icons.search, size: 16, color: s.accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _currentUrl.replaceAll('https://', '').replaceAll('http://', ''),
                  style: TextStyle(fontSize: 12, color: p.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (_loading)
                SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(
                      strokeWidth: 1.5, color: s.accent),
                )
              else
                GestureDetector(
                  onTap: () => _controller.reload(),
                  child: Icon(Icons.refresh, size: 16, color: p.muted),
                ),
            ],
          ),
        ),
        actions: <Widget>[
          PopupMenuButton<String>(
            icon: Icon(Icons.swap_calls_outlined, color: s.accent),
            tooltip: '切换源站 / 镜像',
            onSelected: _switchSource,
            itemBuilder: (BuildContext ctx) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'https://archiveofourown.org/',
                child: Text('🚀 AO3 官方主站 (archiveofourown.org)'),
              ),
              const PopupMenuItem<String>(
                value: 'https://archiveofourown.org/works/search',
                child: Text('🔍 官方作品搜索'),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem<String>(
                value: 'https://nightskies.top/',
                child: Text('🌐 镜像源 1 (nightskies.top)'),
              ),
              const PopupMenuItem<String>(
                value: 'https://ao3.org/',
                child: Text('🌐 镜像源 2 (ao3.org)'),
              ),
            ],
          ),
          const SizedBox(width: 4),
        ],
        bottom: _loading
            ? PreferredSize(
                preferredSize: const Size.fromHeight(2),
                child: LinearProgressIndicator(
                  value: _progress > 0 ? _progress : null,
                  color: s.accent,
                  backgroundColor: Colors.transparent,
                ),
              )
            : null,
      ),
      body: Stack(
        children: <Widget>[
          WebViewWidget(controller: _controller),

          // 浮动操作栏：发现正文时一键进入 Niveous 排版阅读
          if (_isWorkPage)
            Positioned(
              left: 18,
              right: 18,
              bottom: 16,
              child: SafeArea(
                child: Material(
                  elevation: 8,
                  shadowColor: s.accent.withOpacity(0.35),
                  borderRadius: BorderRadius.circular(16),
                  color: s.accent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: _extracting ? null : _openInNiveousReader,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          if (_extracting)
                            const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          else
                            const Icon(Icons.auto_stories,
                                color: Colors.white, size: 20),
                          const SizedBox(width: 10),
                          Text(
                            _extracting
                                ? '正在排版正文与章节...'
                                : '✨ 进入 Niveous 沉浸排版阅读',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          else if (_worksCountOnPage > 0)
            Positioned(
              right: 14,
              bottom: 14,
              child: SafeArea(
                child: FloatingActionButton.extended(
                  onPressed: _saveWorksToLibrary,
                  backgroundColor: p.card,
                  foregroundColor: s.accent,
                  elevation: 4,
                  icon: const Icon(Icons.bookmark_add_outlined, size: 18),
                  label: Text('同步本页 ($_worksCountOnPage 篇) 到书库',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
