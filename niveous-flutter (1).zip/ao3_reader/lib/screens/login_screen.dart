import 'package:flutter/material.dart';

import '../app_state.dart';
import '../palettes.dart';
import '../widgets/paper_scaffold.dart';
import '../widgets/proxy_dialog.dart';
import 'settings_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late final TextEditingController _user =
      TextEditingController(text: '');
  final TextEditingController _pass = TextEditingController(text: '');
  bool _submitting = false;

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _handleRealLogin(AppState s) async {
    final String u = _user.text.trim();
    final String p = _pass.text;

    if (u.isEmpty || p.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('请输入 AO3 用户名和密码'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() => _submitting = true);

    final String? err = await s.loginAo3(u, p);
    if (!mounted) return;
    setState(() => _submitting = false);

    if (err != null) {
      showDialog<void>(
        context: context,
        builder: (BuildContext ctx) {
          final Palette pal = s.palette;
          return AlertDialog(
            backgroundColor: pal.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Row(
              children: <Widget>[
                const Icon(Icons.error_outline, color: Color(0xFFB3261E), size: 22),
                const SizedBox(width: 8),
                Text('登录遇到问题', style: TextStyle(fontSize: 16, color: pal.ink)),
              ],
            ),
            content: Text(
              '$err\n\n提示：\n• 如果是网络超时，请先确认手机已开启代理/VPN软件。\n• 你也可以点击「网络设置」指定本地代理端口或镜像源。\n• 或者点击「访客身份浏览」先直接进入体验。',
              style: TextStyle(fontSize: 13, height: 1.6, color: pal.muted),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(ctx).pop();
                  ProxyDialog.show(context);
                },
                child: Text('网络设置', style: TextStyle(color: s.accent)),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(ctx).pop();
                  s.login(u.isNotEmpty ? u : '访客', guest: true);
                },
                child: Text('以访客进入', style: TextStyle(color: pal.ink2)),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(ctx).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: s.accent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('重试'),
              ),
            ],
          );
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('欢迎回来，${s.userName}！'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    return Scaffold(
      body: PaperScaffold(
        child: SafeArea(
          child: Stack(
            children: <Widget>[
              // 右上角：网络代理 + 深浅色 + 设置
              Positioned(
                top: 12,
                right: 16,
                child: Row(
                  children: <Widget>[
                    _TopIconButton(
                      icon: Icons.wifi_outlined,
                      tooltip: '网络与代理设置',
                      onTap: () => ProxyDialog.show(context),
                    ),
                    const SizedBox(width: 8),
                    _TopIconButton(
                      icon: Icons.brightness_6_outlined,
                      tooltip: '切换深浅色',
                      onTap: () => s.setPaper(p.dark ? 'clear' : 'night'),
                    ),
                    const SizedBox(width: 8),
                    _TopIconButton(
                      icon: Icons.settings_outlined,
                      tooltip: '全局设置',
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => const SettingsScreen(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 26),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: s.accent,
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                  color: s.accent.withOpacity(0.28),
                                  blurRadius: 16,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            alignment: Alignment.center,
                            child: const Text(
                              'N',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'serif',
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Niveous',
                                style: TextStyle(
                                  fontSize: 23,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'serif',
                                  color: p.ink,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '一个更舒服的 AO3 阅读器',
                                style: TextStyle(
                                    fontSize: 12, color: p.muted),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 34),
                      _FieldLabel('AO3 用户名 / 邮箱', color: p.muted),
                      _PTextField(controller: _user, hint: 'your_ao3_name'),
                      const SizedBox(height: 14),
                      _FieldLabel('密码', color: p.muted),
                      _PTextField(
                        controller: _pass,
                        hint: '••••••••',
                        obscure: true,
                      ),
                      const SizedBox(height: 20),
                      _PrimaryButton(
                        label: _submitting ? '正在登录 AO3...' : '登录 AO3 账号',
                        isLoading: _submitting,
                        onTap: _submitting ? () {} : () => _handleRealLogin(s),
                      ),
                      const SizedBox(height: 10),
                      _GhostButton(
                        label: '以访客身份浏览',
                        onTap: () => s.login('', guest: true),
                      ),
                      const SizedBox(height: 22),
                      Text.rich(
                        TextSpan(
                          children: <InlineSpan>[
                            TextSpan(
                              text: '账号安全声明：\n',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                color: p.ink2,
                              ),
                            ),
                            TextSpan(
                              text: '本应用直连 AO3 官方登录接口，所有凭据仅保存在你手机本地。'
                                  '登录后可获取你的私密书签、个人偏好与锁章作品。\n'
                                  '中国大陆用户请确保手机已开启代理/VPN。',
                            ),
                          ],
                          style: TextStyle(
                              fontSize: 11.5, height: 1.6, color: p.muted),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopIconButton extends StatelessWidget {
  const _TopIconButton({
    required this.icon,
    required this.onTap,
    this.tooltip = '',
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: p.card.withOpacity(0.92),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: p.line),
          ),
          child: Icon(icon, size: 18, color: p.ink2),
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text, {required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 3, bottom: 6),
      child: Text(text, style: TextStyle(fontSize: 12, color: color)),
    );
  }
}

class _PTextField extends StatelessWidget {
  const _PTextField({
    required this.controller,
    required this.hint,
    this.obscure = false,
  });

  final TextEditingController controller;
  final String hint;
  final bool obscure;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: TextStyle(fontSize: 15, color: p.ink),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: p.muted, fontSize: 14),
        filled: true,
        fillColor: p.card,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: s.accent, width: 1.6),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({
    required this.label,
    required this.onTap,
    this.isLoading = false,
  });

  final String label;
  final VoidCallback onTap;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    return SizedBox(
      height: 52,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: s.accent,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.2,
                  color: Colors.white,
                ),
              )
            : Text(label,
                style: const TextStyle(
                    fontSize: 15.5, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _GhostButton extends StatelessWidget {
  const _GhostButton({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;
    return SizedBox(
      height: 50,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: p.ink2,
          side: BorderSide(color: p.line),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: Text(label,
            style:
                const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
      ),
    );
  }
}
