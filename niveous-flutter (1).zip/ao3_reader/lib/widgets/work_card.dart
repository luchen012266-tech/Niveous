import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../palettes.dart';

/// 作品卡片（精致卡片流设计，字号随 cardFontSize 响应，阿拉伯数字日期）
class WorkCard extends StatelessWidget {
  const WorkCard({
    super.key,
    required this.work,
    required this.bookmarked,
    required this.onBookmark,
    required this.onOpen,
  });

  final Work work;
  final bool bookmarked;
  final VoidCallback onBookmark;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final AppState s = AppScope.of(context);
    final Palette p = s.palette;

    final Color ratingColor = Color(
      kRatingColors[work.rating] ?? 0xFF2E7D32,
    );

    final double baseFs = s.cardFontSize;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onOpen,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: p.line),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: Colors.black.withOpacity(p.dark ? 0.25 : 0.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // 左侧分级色条
              Container(width: 4, color: ratingColor),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      // 顶部：分级徽章 + 完结状态 + 纯阿拉伯数字日期
                      Row(
                        children: <Widget>[
                          _Badge(
                            text: work.rating,
                            color: ratingColor,
                            textColor: Colors.white,
                            bold: true,
                          ),
                          const SizedBox(width: 6),
                          if (work.complete)
                            const _Badge(
                              text: '完结',
                              color: Color(0xFFE8F3E8),
                              textColor: Color(0xFF2E7D32),
                            ),
                          if (work.zhReady) ...<Widget>[
                            const SizedBox(width: 6),
                            _Badge(
                              text: '已有译文',
                              color: p.dark
                                  ? const Color(0xFF123027)
                                  : const Color(0xFFE3F4EE),
                              textColor: p.dark
                                  ? const Color(0xFF5EC9A3)
                                  : const Color(0xFF0B6E4F),
                            ),
                          ],
                          const Spacer(),
                          // 纯阿拉伯数字日期，例如 2024.03.15
                          Text(
                            work.displayArabicDate,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: p.muted,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // 文章标题（点进去直接进入阅读器）
                      Text(
                        work.displayTitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: baseFs + 2.5,
                          height: 1.35,
                          fontWeight: FontWeight.w700,
                          color: p.ink,
                          fontFamily: s.globalFontFamily,
                        ),
                      ),
                      if (work.hasZhTitle) ...<Widget>[
                        const SizedBox(height: 2),
                        Text(
                          work.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: baseFs - 2,
                            fontStyle: FontStyle.italic,
                            color: p.muted,
                            fontFamily: 'serif',
                          ),
                        ),
                      ],
                      const SizedBox(height: 4),

                      // 作者与原作圈
                      Text.rich(
                        TextSpan(
                          children: <InlineSpan>[
                            TextSpan(
                              text: 'by ',
                              style: TextStyle(color: p.muted, fontSize: baseFs - 2.5),
                            ),
                            TextSpan(
                              text: work.author,
                              style: TextStyle(
                                color: s.accent,
                                fontWeight: FontWeight.w600,
                                fontSize: baseFs - 2,
                              ),
                            ),
                            TextSpan(
                              text: '  ·  ${work.fandom}',
                              style: TextStyle(color: p.muted, fontSize: baseFs - 2.5),
                            ),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),

                      // 配对 / 关系标签
                      if (work.relationship.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                          decoration: BoxDecoration(
                            color: s.accentSoft,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '❤️ ${work.relationship}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: baseFs - 2.5,
                              color: s.accent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],

                      // 简介摘要
                      if (work.summary.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 8),
                        Text(
                          work.summaryZh.isNotEmpty ? work.summaryZh : work.summary,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: baseFs - 1.5,
                            height: 1.55,
                            color: p.ink2,
                          ),
                        ),
                      ],

                      const SizedBox(height: 10),

                      // 底部统计：Kudos、字数、章节数、加入书签按钮
                      Row(
                        children: <Widget>[
                          Icon(Icons.favorite_outline, size: 13, color: p.muted),
                          const SizedBox(width: 3),
                          Text(work.kudos,
                              style: TextStyle(fontSize: 11, color: p.muted)),
                          const SizedBox(width: 10),
                          Icon(Icons.visibility_outlined, size: 13, color: p.muted),
                          const SizedBox(width: 3),
                          Text(work.hits,
                              style: TextStyle(fontSize: 11, color: p.muted)),
                          const SizedBox(width: 10),
                          Text('${work.words} 词',
                              style: TextStyle(fontSize: 11, color: p.muted)),
                          const Spacer(),
                          IconButton(
                            icon: Icon(
                              bookmarked ? Icons.bookmark : Icons.bookmark_border,
                              color: bookmarked ? s.accent : p.muted,
                              size: 19,
                            ),
                            onPressed: onBookmark,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                            tooltip: bookmarked ? '移出书库' : '加入书库',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({
    required this.text,
    required this.color,
    required this.textColor,
    this.bold = false,
  });

  final String text;
  final Color color;
  final Color textColor;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
          color: textColor,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}
