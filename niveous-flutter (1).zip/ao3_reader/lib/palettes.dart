import 'package:flutter/material.dart';

/// 纸面色板。精心调配的莫兰迪/淡雅色系，彻底告别黄色与刺眼大红。
class Palette {
  final String key;
  final String name;
  final String swatch; // 只有颜色预设按钮用，值为 hex
  final Color paper;
  final Color card;
  final Color line;
  final Color ink;
  final Color ink2;
  final Color muted;
  final bool dark;

  const Palette({
    required this.key,
    required this.name,
    required this.swatch,
    required this.paper,
    required this.card,
    required this.line,
    required this.ink,
    required this.ink2,
    required this.muted,
    this.dark = false,
  });

  Color get swatchColor => parseHex(swatch);
}

Color parseHex(String hex) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  return Color(int.parse(h, radix: 16));
}

/// 优雅柔和预设配色（淡紫、丁香、烟粉、暮山紫、云灰、纯白、夜间黑）
const List<Palette> kPalettes = <Palette>[
  Palette(
    key: 'clear',
    name: '纯白',
    swatch: '#ffffff',
    paper: Color(0xFFFFFFFF),
    card: Color(0xFFFFFFFF),
    line: Color(0xFFE8E5EC),
    ink: Color(0xFF231F2A),
    ink2: Color(0xFF5A5265),
    muted: Color(0xFF8F889C),
  ),
  Palette(
    key: 'mist_purple',
    name: '雾紫',
    swatch: '#e7e2ee',
    paper: Color(0xFFE7E2EE),
    card: Color(0xFFF3EFF8),
    line: Color(0xFFD6CEDF),
    ink: Color(0xFF252030),
    ink2: Color(0xFF564E66),
    muted: Color(0xFF8B819E),
  ),
  Palette(
    key: 'lilac',
    name: '丁香',
    swatch: '#dcd2ee',
    paper: Color(0xFFDCD2EE),
    card: Color(0xFFE9E2F6),
    line: Color(0xFFC7BBE0),
    ink: Color(0xFF261E36),
    ink2: Color(0xFF584A72),
    muted: Color(0xFF8879A5),
  ),
  Palette(
    key: 'smoke_pink',
    name: '烟粉',
    swatch: '#eedeea',
    paper: Color(0xFFEEDEEA),
    card: Color(0xFFF7ECF4),
    line: Color(0xFFDEC3D7),
    ink: Color(0xFF2C1D27),
    ink2: Color(0xFF634A5B),
    muted: Color(0xFF96768D),
  ),
  Palette(
    key: 'twilight',
    name: '暮山紫',
    swatch: '#c5bece',
    paper: Color(0xFFC5BECE),
    card: Color(0xFFD5CFDC),
    line: Color(0xFFAFA6BA),
    ink: Color(0xFF221A2C),
    ink2: Color(0xFF4C3F5C),
    muted: Color(0xFF756788),
  ),
  Palette(
    key: 'cloud_gray',
    name: '云灰',
    swatch: '#e5e7eb',
    paper: Color(0xFFE5E7EB),
    card: Color(0xFFF1F3F5),
    line: Color(0xFFD0D5DD),
    ink: Color(0xFF1F242F),
    ink2: Color(0xFF475467),
    muted: Color(0xFF7D899B),
  ),
  Palette(
    key: 'night',
    name: '夜间墨黑',
    swatch: '#1a191e',
    paper: Color(0xFF1A191E),
    card: Color(0xFF24222A),
    line: Color(0xFF34303D),
    ink: Color(0xFFEDE9F5),
    ink2: Color(0xFFB4ACBF),
    muted: Color(0xFF7E768B),
    dark: true,
  ),
];

/// 强调色预设（默认是温雅的暮紫）
class AccentPreset {
  final String key;
  final String name;
  final String hex;
  const AccentPreset(this.key, this.name, this.hex);
}

const List<AccentPreset> kAccents = <AccentPreset>[
  AccentPreset('violet', '暮山紫', '#6b5e82'),
  AccentPreset('coral', '暖烟粉', '#8c5a75'),
  AccentPreset('lavender', '薰衣草', '#5d4f7a'),
  AccentPreset('indigo', '暮靛蓝', '#415273'),
  AccentPreset('graphite', '玄墨黑', '#3b3746'),
];

Color mixColor(Color a, Color b, double t) {
  return Color.lerp(a, b, t)!;
}

Palette paletteByKey(String key) {
  return kPalettes.firstWhere(
    (p) => p.key == key,
    orElse: () => kPalettes.first,
  );
}
