import 'package:flutter/material.dart';

/// 一个可排版的最小单位：一段正文 / 一个标题 / 一行说明。
class ReaderBlock {
  final String text;

  /// head | meta | en | zh
  final String kind;
  final double spaceAfter;

  const ReaderBlock(this.text, this.kind, {this.spaceAfter = 14});
}

/// 高精度无缝分页器：
/// 当一段文字超出当前页剩余高度时，自动在断句/换行处精准拆分，
/// 将前段填满当前页底部，后段移入下一页，彻底消除页面底部大片空白！
class Paginator {
  static List<List<ReaderBlock>> paginate({
    required List<ReaderBlock> blocks,
    required double width,
    required double height,
    required TextStyle Function(String kind) styleOf,
  }) {
    final List<List<ReaderBlock>> pages = <List<ReaderBlock>>[];
    List<ReaderBlock> current = <ReaderBlock>[];
    double used = 0;

    for (final ReaderBlock b in blocks) {
      final TextStyle style = styleOf(b.kind);
      final TextPainter tp = TextPainter(
        text: TextSpan(text: b.text, style: style),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: width);

      final double totalH = tp.height + b.spaceAfter;

      // 1. 如果当前页放得下整段
      if (used + totalH <= height) {
        current.add(b);
        used += totalH;
        continue;
      }

      // 2. 当前页剩余高度
      final double remainH = height - used;

      // 如果剩余高度还能放得下至少 1~2 行文字（约 > 35px），进行精准拆词断行填满底部
      if (remainH > 35 && b.text.length > 20 && b.kind != 'head') {
        final TextPosition pos = tp.getPositionForOffset(Offset(width, remainH - b.spaceAfter));
        int splitIdx = pos.offset;

        // 优先在句号、逗号、空格或换行处断开，保证断句自然
        if (splitIdx > 0 && splitIdx < b.text.length) {
          int naturalBreak = -1;
          for (int i = splitIdx; i >= (splitIdx - 25) && i > 0; i--) {
            final String ch = b.text[i];
            if (ch == '。' || ch == '，' || ch == '！' || ch == '？' || ch == '.' || ch == ',' || ch == ' ' || ch == '\n') {
              naturalBreak = i + 1;
              break;
            }
          }
          if (naturalBreak > 0) {
            splitIdx = naturalBreak;
          }

          final String part1 = b.text.substring(0, splitIdx).trimRight();
          final String part2 = b.text.substring(splitIdx).trimLeft();

          if (part1.isNotEmpty && part2.isNotEmpty) {
            // 前半部分填满当前页
            current.add(ReaderBlock(part1, b.kind, spaceAfter: 0));
            pages.add(current);

            // 后半部分开启下一页
            current = <ReaderBlock>[];
            used = 0;

            // 测量后半部分
            final TextPainter tp2 = TextPainter(
              text: TextSpan(text: part2, style: style),
              textDirection: TextDirection.ltr,
            )..layout(maxWidth: width);

            current.add(ReaderBlock(part2, b.kind, spaceAfter: b.spaceAfter));
            used = tp2.height + b.spaceAfter;
            continue;
          }
        }
      }

      // 如果剩余高度太小，整段移至下一页
      if (current.isNotEmpty) {
        pages.add(current);
        current = <ReaderBlock>[];
        used = 0;
      }
      current.add(b);
      used += totalH;
    }

    if (current.isNotEmpty) pages.add(current);
    if (pages.isEmpty) pages.add(<ReaderBlock>[]);
    return pages;
  }
}
